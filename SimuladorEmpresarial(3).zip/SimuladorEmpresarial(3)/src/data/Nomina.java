/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.util.Scanner;
import data.Empleados;
/**
 *
 * @author AIDA GOMEZ
 */
public class Nomina extends Empleados {
    private int horasTrabajadas;
    private int auxilioTransporte;
    private double eps;
    private double afp;
    private double arl;
    private double sena;
    private double icbf;
    private double ccf;
    private double vacaciones;
    private double prima;
    private double cesantias;
    private double intCesantias;

    public int getAuxilioTransporte() {
        return auxilioTransporte;
    }

    public void setAuxilioTransporte(int auxilioTransporte) {
        this.auxilioTransporte = auxilioTransporte;
    }

    public double getIcbf() {
        return icbf;
    }

    public void setIcbf(double icbf) {
        this.icbf = icbf;
    }

    public double getCcf() {
        return ccf;
    }

    public void setCcf(double ccf) {
        this.ccf = ccf;
    }

    public double getIntCesantias() {

        return intCesantias;
    }

    public void setIntCesantias(double intCesantias) {

        this.intCesantias = intCesantias;
    }

    public int getHorasTrabajadas() {

        return horasTrabajadas;
    }

    public double getPrima() {

        return prima;
    }

    public double getCesantias() {

        return cesantias;
    }

    public double getArl() {

        return arl;
    }

    public double getEps() {

        return eps;
    }

    public double getAfp() {

        return afp;
    }

   public double getVacaciones() {

        return vacaciones;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {

        this.horasTrabajadas = horasTrabajadas;
    }

    public void setPrima(double prima) {

        this.prima = prima;
    }

    public void setCesantias(double cesantias) {

        this.cesantias = cesantias;
    }

    public void setArl(double arl) {

        this.arl = arl;
    }

    public void setEps(double eps) {

        this.eps = eps;
    }

    public void setAfp(double afp) {

        this.afp = afp;
    }

    public void setVacaciones(double vacaciones) {

        this.vacaciones = vacaciones;
    }

    public double getSena() {
        return sena;
    }

    public void setSena(double sena) {
        this.sena = sena;
    }

    @Override
   public void generarPagoSueldo(){
           Scanner sn=new Scanner(System.in);    
           boolean respuesta;
           int tiempoPrima, tiempoVacaciones;
           int sueldo, total, acum, mas;
           System.out.println("Ingrese el sueldo del empleado: $");
           sueldo=sn.nextInt();
           System.out.println("Hace cuanto se le consigno la ultima prima? (tiempo en meses)");
           tiempoPrima=sn.nextInt();
           System.out.println("Hace cuanto fueron las ultimas vacaciones del trabajador? (tiempo en meses)");
           tiempoVacaciones=sn.nextInt();
           if (sueldo>0) {
               if(tiempoVacaciones>=12^tiempoPrima==12){
                   acum=tiempoVacaciones/12;
                   total=sueldo+(acum*sueldo)+sueldo;
               }if(tiempoPrima==12^tiempoVacaciones<12){
                   total=sueldo+sueldo;
               }if(tiempoPrima!=12^tiempoVacaciones>=12){
                   acum=tiempoVacaciones/12;
                   total=(acum*sueldo)+sueldo;}          
        }else{
               System.out.println("Valor incorrecto");
           }
           System.out.println("El trabajador va a retirar cesantias?");
           respuesta=sn.nextBoolean();
           if(respuesta==true){
               mas=(12*sueldo)/100;
               System.out.println("El valor se le sumara al sueldo");
           }else{
               System.out.println("No se le suma al sueldo");
           }
           }

    public Nomina(int sueldo, String cargo, int prima, int vacaciones, int cesantias, int intCesantias) {
        this.setSueldo(sueldo);
        this.setCargo(cargo);
        this.prima = prima;
        this.vacaciones=vacaciones;
        this.cesantias=cesantias;
        this.intCesantias=intCesantias;

    }
    @Override
    public String toString(){
        return "su salario es: "+this.getSueldo();
    }


}

