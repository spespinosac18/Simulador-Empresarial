/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.util.Scanner;

public class PrestacionServicios extends Empleados{
    private boolean informeServicios;
    private boolean certificadoSeguridadSocial;

    public boolean isInformeServicios() {
        return informeServicios;
    }

    public void setInformeServicios(boolean informeServicios) {
        this.informeServicios = informeServicios;
    }

    public boolean isCertificadoSeguridadSocial() {
        return certificadoSeguridadSocial;
    }

    public void setCertificadoSeguridadSocial(boolean certificadoSeguridadSocial) {
        this.certificadoSeguridadSocial = certificadoSeguridadSocial;
    }

   @Override
   public void generarPagoSueldo(){
       Scanner sn=new Scanner(System.in);
       boolean seguridadSocial;
       double sueldo, total;
       System.out.println("El empleado presento el pago de seguridad social este mes?");
       seguridadSocial=sn.nextBoolean();
        System.out.println("Ingrese el sueldo del empleado: $");
           sueldo=sn.nextDouble();
       if(seguridadSocial==true){
           total=sueldo;
       }else{
           System.out.println("No se puede generar el pago al empleado");
       }
       
   }
}
